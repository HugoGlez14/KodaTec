<?php

define("KEY_TOKEN", "RZK234_234*")

?>