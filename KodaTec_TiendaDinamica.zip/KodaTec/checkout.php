<?php

require 'config/config.php';
require 'config/database.php';
$db = new Database();
$con = $db->conectar();

$productos = isset($_SESSION['carrito']['producto']) ? $_SESSION['carrito']['producto'] : null;

$listaCarrito = array();
if ($productos != null)
{
    foreach($productos as $clave => $cantidad)
    {
        $sql = $con->prepare("SELECT id, nombre, precio, $cantidad AS cantidad FROM producto WHERE id =? AND activo=1");
        $sql->execute([$clave]);
        $listaCarrito[] = $sql->fetch(PDO::FETCH_ASSOC);

    }
}




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=S, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilosTienda.css">
    <title>Document</title>
</head>
<body>
<header data-bs-theme="dark">

  <div class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a href="#" class="navbar-brand ">
        <strong>KodaTec</strong>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarHeader">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
                <a href="#" class="nav-link active"> catalogo</a>
            </li>
              <li class="nav-item">
                <a href="#" class="nav-link active"> contacto</a>
            </li>
        </ul>
        <a href="carrito.php" class="btn btn-primary">
          carritos <span id="num_cart" class="badge bg-secondary"><?php echo $num_cart; ?></span></a>


      </div>
    </div>
  </div>
</header>
<main>
    <div class="container">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>producto</th>
                        <th>precio</th>
                        <th>Cantidad</th>
                        <th>subtotal</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($listaCarrito == null){
                        echo '<tr><td colspan="5" class="text-center"><b>Lista vacia</b></td></tr>';
                    }else{
                        $total = 0; 
                        foreach($listaCarrito as $producto){

                            $_id = $producto['id'];
                            $nombre = $producto['nombre'];
                            $precio = $producto['precio'];
                            $cantidad = $producto['cantidad'];
                            $subtotal = $cantidad * $precio;
                            $total += $subtotal;
                            ?>
                    <tr>
                        <td><?php echo $nombre; ?></td>
                        <td><?php echo MONEDA . number_format($precio, 2, '.', ','); ?></td>
                        <td>
                            <input type="number" min="1" max="10" step="1" value="<?php $cantidad ?>" size="5" id="cantidad_<?php echo $_id; ?>"
                            onchange="actualizaCantidad(this.value,)">
                        </td>
                        <td>
                            <div id="subtotal_<?php echo $_id ?>" name="subtotal[]">
                                <?php echo MONEDA . number_format($subtotal, 2, '.', ',');  ?>
                            </div>
                        </td>
                        <td>
                            <a href="#" id="eliminar"  class="btn btn-warning btn-sm" data-bs-id="
                            <?php echo $_id; ?>" data-bs-toggle="modal" data-bs-target="eliminaModal">Eliminar</a>
                        </td>
                    </tr>
                    <?php } ?> 

                    <tr>
                        <td colspan="3"></td>
                        <td colspan="2">
                            <p class="h3" id="total"><?php echo MONEDA . number_format($total, 2, '.', ',') ?></p>
                        </td>
                    </tr>
                </tbody>
            <?php } ?>
            </table>

        </div>

        <div class="row">
            <div class="col-md-5 offset-md-7 d-grid gap-2">
                <button class="btn btn-primary btn-lg">Realizar Pago</button>
            </div>

        </div>
        
    </div>

</main>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
<script>
  function addproducto(id, token){
    let url = 'clases/carrito.php';
    let formData = new FormData()
    formData.append('id', id)
    formData.append('token', token)

    fetch(url, {
      method:'POST', 
      body: formData, 
      mode: 'cors'
    }).then(response => response.json())
    .then(data  =>{
      if(data.ok){
        let elemento = document.getElementById("num_cart")
        elemento.innerHTML = data.numero
      }
    })


  }
</script>
</body>
</html>